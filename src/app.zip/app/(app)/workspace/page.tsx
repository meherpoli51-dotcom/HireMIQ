"use client";

import { useState, useEffect } from "react";
import { AppNavbar } from "@/components/layout/app-navbar";
import { InputPanel } from "@/components/workspace/input-panel";
import { OutputPanel } from "@/components/workspace/output-panel";
import { UpgradeModal } from "@/components/billing/upgrade-modal";
import type { JDInput, AnalysisResult } from "@/lib/types";

interface WorkspaceInfo {
  id: string;
  name: string;
  tier: "free" | "pro" | "enterprise";
  role: string;
}

interface CreditInfo {
  monthly_limit: number;
  monthly_used: number;
  total_available: number;
  percent_used: number;
  resets_at: string;
}

export default function WorkspacePage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Workspace + billing state
  const [workspace, setWorkspace] = useState<WorkspaceInfo | null>(null);
  const [credits, setCredits] = useState<CreditInfo | null>(null);
  const [showUpgrade, setShowUpgrade] = useState(false);

  // Load workspace on mount
  useEffect(() => {
    fetch("/api/workspace/me")
      .then((r) => r.json())
      .then((data) => {
        if (data.workspace) {
          setWorkspace(data.workspace);
        }
      })
      .catch(console.error);
  }, []);

  // Load credit usage whenever workspace is known
  useEffect(() => {
    if (!workspace?.id) return;
    fetch(`/api/billing/usage?workspace_id=${workspace.id}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.credits) setCredits(data.credits);
      })
      .catch(console.error);
  }, [workspace?.id]);

  const handleAnalyze = async (input: JDInput) => {
    // Hard-block if no credits (UX guard — server also checks)
    if (credits && credits.total_available <= 0) {
      setShowUpgrade(true);
      return;
    }

    setIsAnalyzing(true);
    setResult(null);
    setError(null);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...input,
          workspace_id: workspace?.id,
        }),
      });

      if (response.status === 402) {
        // Payment required — credit limit hit server-side
        setShowUpgrade(true);
        return;
      }

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Analysis failed");
      }

      const data = await response.json();

      if (data._mock) {
        console.info(
          "Running with mock data. Set ANTHROPIC_API_KEY in .env.local for real AI analysis."
        );
      }

      setResult(data);

      // Refresh credits after successful analysis
      if (workspace?.id) {
        fetch(`/api/billing/usage?workspace_id=${workspace.id}`)
          .then((r) => r.json())
          .then((d) => d.credits && setCredits(d.credits))
          .catch(console.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <>
      <AppNavbar title="JD Analysis Workspace" />

      {/* Credit usage banner (only when near/at limit) */}
      {credits && credits.percent_used >= 60 && (
        <div
          className={`px-6 py-2 flex items-center justify-between text-xs border-b ${
            credits.total_available === 0
              ? "bg-rose-50 border-rose-200 text-rose-800"
              : "bg-amber-50 border-amber-200 text-amber-800"
          }`}
        >
          <span className="font-medium">
            {credits.total_available === 0
              ? `Monthly limit reached — ${credits.monthly_used}/${credits.monthly_limit} analyses used`
              : `${credits.total_available} of ${credits.monthly_limit} analyses remaining this month`}
          </span>
          {credits.total_available === 0 && (
            <button
              onClick={() => setShowUpgrade(true)}
              className="ml-4 px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg transition-colors"
            >
              Upgrade to Pro ₹499/mo
            </button>
          )}
        </div>
      )}

      <div className="flex-1 flex overflow-hidden">
        <InputPanel
          onAnalyze={handleAnalyze}
          isAnalyzing={isAnalyzing}
          credits={credits}
          onUpgradeClick={() => setShowUpgrade(true)}
        />
        <OutputPanel result={result} isAnalyzing={isAnalyzing} error={error} />
      </div>

      {/* Upgrade Modal */}
      <UpgradeModal
        open={showUpgrade}
        workspaceId={workspace?.id}
        currentUsage={credits?.monthly_used}
        limit={credits?.monthly_limit}
        tier={workspace?.tier ?? "free"}
        onClose={() => setShowUpgrade(false)}
      />
    </>
  );
}
