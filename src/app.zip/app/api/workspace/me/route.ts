import { NextRequest } from "next/server";
import { requireAuth, errorResponse, successResponse } from "@/lib/api-utils";
import { createServerClient } from "@/lib/supabase";

/**
 * GET /api/workspace/me
 * Returns the current user's primary workspace (or first workspace found).
 * Used by the frontend to get workspace_id for billing/usage calls.
 */
export async function GET(request: NextRequest) {
  try {
    const { error: authError, session } = await requireAuth(request);
    if (authError) return authError;

    const userId = session!.user!.id!;

    // If session already has workspaceId, return it fast
    const sessionWorkspaceId = (session!.user as any).workspaceId;

    const db = createServerClient() as any;

    // Fetch the primary workspace for this user
    const { data: member } = await db
      .from("workspace_members")
      .select(`
        workspace_id,
        role,
        workspaces (
          id,
          name,
          slug,
          tier,
          max_members,
          members_count
        )
      `)
      .eq("user_id", userId)
      .order("created_at", { ascending: true })
      .limit(1)
      .single();

    if (!member?.workspaces) {
      // Workspace missing — create it on the fly
      const slug = `ws-${userId.replace(/-/g, "").slice(0, 12)}-${Date.now()}`;
      const { data: workspace, error } = await db
        .from("workspaces")
        .insert({
          name: "My Workspace",
          slug,
          owner_id: userId,
          tier: "free",
          max_members: 1,
        })
        .select("id, name, slug, tier, max_members, members_count")
        .single();

      if (error || !workspace) {
        return errorResponse("Failed to create workspace", 500);
      }

      await db.from("workspace_members").insert({
        workspace_id: workspace.id,
        user_id: userId,
        role: "owner",
        accepted_at: new Date().toISOString(),
      });

      return successResponse({
        workspace: {
          ...workspace,
          role: "owner",
        },
      });
    }

    return successResponse({
      workspace: {
        ...member.workspaces,
        role: member.role,
      },
    });
  } catch (error) {
    console.error("GET /api/workspace/me error:", error);
    return errorResponse("Failed to get workspace", 500);
  }
}
