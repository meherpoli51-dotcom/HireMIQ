import { NextRequest, NextResponse } from "next/server";
import { analyzeJD } from "@/lib/ai/analyze";
import { mockAnalysisResult } from "@/lib/mock-data";
import { requireAuth, errorResponse, successResponse } from "@/lib/api-utils";
import { canAnalyzeJD, logJDAnalysis } from "@/lib/billing";
import type { JDInput } from "@/lib/types";

export async function POST(request: NextRequest) {
  try {
    // Require authentication
    const { error: authError, session } = await requireAuth(request);
    if (authError) return authError;

    const userId = session!.user!.id!;

    const input: JDInput = await request.json();

    // Get workspace_id from request (required for billing)
    const workspaceId = (input as any).workspace_id || request.nextUrl.searchParams.get('workspace_id');
    if (!workspaceId) {
      return errorResponse('workspace_id is required', 400);
    }

    // Check if user has credits to analyze
    const creditCheck = await canAnalyzeJD(workspaceId);
    if (!creditCheck.can) {
      return NextResponse.json(
        { error: creditCheck.reason, upgrade_required: true },
        { status: 402 } // 402 Payment Required
      );
    }

    // Check if API key is configured
    const apiKey = process.env.ANTHROPIC_API_KEY;
    let result: any;

    if (!apiKey || apiKey === "your-api-key-here") {
      // Fall back to mock data when no API key is set
      // Simulate processing delay for realistic UX
      await new Promise((resolve) => setTimeout(resolve, 2000));
      result = {
        ...mockAnalysisResult,
        jobTitle: input.jobTitle || mockAnalysisResult.jobTitle,
        clientName: input.clientName || mockAnalysisResult.clientName,
        id: `analysis-${Date.now()}`,
        createdAt: new Date().toISOString(),
        _mock: true,
      };
    } else {
      // Real Claude-powered analysis
      result = await analyzeJD(input);
    }

    // Log usage
    try {
      await logJDAnalysis(
        workspaceId,
        userId,
        result.id,
        input.jobTitle,
        input.clientName
      );
    } catch (logError) {
      console.error("Error logging usage:", logError);
      // Don't fail the analysis if logging fails
    }

    return successResponse(result);
  } catch (error) {
    console.error("Analysis error:", error);

    const message =
      error instanceof Error ? error.message : "Analysis failed";

    return errorResponse(message, 500);
  }
}
